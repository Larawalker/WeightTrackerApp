package com.example.weighttrackerapp;

public class SmsHelper {
    private static final int REQ_SMS = 42;

    public static boolean hasSmsPermission(Activity a){
        return ContextCompat.checkSelfPermission(a,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    public static void requestSmsPermission(Activity a){
        ActivityCompat.requestPermissions(a,
                new String[]{Manifest.permission.SEND_SMS},
                REQ_SMS);
    }

    public static void maybeSendGoalReached(Activity a, String message){
        if (hasSmsPermission(a)) {
            sendSms("+15551234567", message); // replace with user's phone from profile if you capture it
            Toast.makeText(a, "SMS alert sent.", Toast.LENGTH_SHORT).show();
        } else {
            // graceful fallback (no crash, app continues to work)
            showLocalNotification(a, message);
            Toast.makeText(a, "SMS permission not granted. Posted local notification.", Toast.LENGTH_LONG).show();
        }
    }

    @SuppressLint("MissingPermission")
    private static void sendSms(String phone, String msg){
        SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null);
    }

    private static void showLocalNotification(Context ctx, String msg){
        // Use NotificationCompat to post a notification as fallback
        // (channel creation omitted for brevity)
    }
}

