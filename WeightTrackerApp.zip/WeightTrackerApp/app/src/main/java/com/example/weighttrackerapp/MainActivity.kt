package com.example.weighttrackerapp

import android.database.Cursor
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.time.LocalDate


class MainActivity() : AppCompatActivity(), Parcelable {
    private var userId: Long = 0
    private var weightDao: WeightDao? = null
    private var adapter: WeightAdapter? = null

    constructor(parcel: Parcel) : this() {
        userId = parcel.readLong()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)

        userId = intent.getLongExtra("USER_ID", -1)
        weightDao = WeightDao(this)

        val rv = findViewById<RecyclerView>(R.id.rvWeights)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = WeightAdapter(object : WeightAdapter.Listener {
            override fun onEdit(r: WeightAdapter.Row) { /* show dialog -> update */
            }

            override fun onDelete(r: WeightAdapter.Row) {
                weightDao!!.deleteWeight(r.id)
                refresh()
            }
        })
        rv.adapter = adapter

        findViewById<View>(R.id.btnAdd).setOnClickListener { v: View? -> openAdd() }
        findViewById<View>(R.id.btnSetGoal).setOnClickListener { v: View? -> promptGoal() }

        refresh()
    }

    private fun openAdd() {
        // For brevity, inline add (you can use AddWeightActivity)
        val w =  /* read from dialog */0.0
        val today = LocalDate.now().toString()
        weightDao!!.addWeight(userId, today, w)
        if (weightDao!!.reachedGoal(userId, w)) {
            SmsHelper.maybeSendGoalReached(this, "Goal reached at $w!")
        }
        refresh()
    }

    private fun promptGoal() {
        // Simple input dialog to set goal, then:
        val goal =  /* user input */0.0
        weightDao!!.setGoal(userId, goal)
        Toast.makeText(this, "Goal set: $goal", Toast.LENGTH_SHORT).show()
    }

    private fun refresh() {
        val c: Cursor = weightDao!!.allForUser(userId)
        adapter!!.submitCursor(c)
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeLong(userId)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<MainActivity> {
        override fun createFromParcel(parcel: Parcel): MainActivity {
            return MainActivity(parcel)
        }

        override fun newArray(size: Int): Array<MainActivity?> {
            return arrayOfNulls(size)
        }
    }
}

