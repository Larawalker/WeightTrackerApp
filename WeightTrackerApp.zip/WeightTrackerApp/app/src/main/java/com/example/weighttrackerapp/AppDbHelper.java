package com.example.weighttrackerapp;

public class AppDbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "weight_app.db";
    public static final int DB_VERSION = 1;

    public AppDbHelper(Context ctx){ super(ctx, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT UNIQUE," +
                "password TEXT NOT NULL)");

        db.execSQL("CREATE TABLE weights(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER," +
                "date TEXT," +
                "weight REAL," +
                "FOREIGN KEY(user_id) REFERENCES users(id))");

        db.execSQL("CREATE TABLE goals(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER UNIQUE," +
                "goal_weight REAL," +
                "FOREIGN KEY(user_id) REFERENCES users(id))");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS goals");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }
}

