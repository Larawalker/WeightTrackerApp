package com.example.weighttrackerapp;

import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private UserDao userDao;
    private EditText etU, etP;
    private Button btnLogin, btnRegister;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);

        userDao = new UserDao(this);

        // IDs match your current activity_login.xml
        etU = findViewById(R.id.editTextUsername);
        etP = findViewById(R.id.editTextPassword);
        btnLogin = findViewById(R.id.buttonLogin);
        btnRegister = findViewById(R.id.buttonRegister);

        btnLogin.setOnClickListener(v -> {
            long uid = userDao.getUserIdIfValid(
                    etU.getText().toString().trim(),
                    etP.getText().toString());
            if (uid > 0) {
                startMain(uid);
            } else {
                Toast.makeText(this, "Invalid credentials.", Toast.LENGTH_SHORT).show();
            }
        });

        btnRegister.setOnClickListener(v -> {
            try {
                long id = userDao.createUser(
                        etU.getText().toString().trim(),
                        etP.getText().toString());
                if (id > 0) {
                    startMain(id);
                } else {
                    Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
                }
            } catch (SQLiteConstraintException ex) {
                Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startMain(long userId) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("USER_ID", userId);
        startActivity(i);
        finish();
    }
}

