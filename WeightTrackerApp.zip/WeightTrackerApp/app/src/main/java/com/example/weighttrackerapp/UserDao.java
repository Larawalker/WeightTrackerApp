package com.example.weighttrackerapp;

public class UserDao {
    private final AppDbHelper helper;
    public UserDao(Context ctx){ helper = new AppDbHelper(ctx); }

    public long createUser(String u, String p){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", u.trim());
        cv.put("password", p); // demo only; prod: hash + salt
        return db.insert("users", null, cv);
    }

    public long getUserIdIfValid(String u, String p){
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM users WHERE username=? AND password=?",
                new String[]{u.trim(), p});
        long id = -1;
        if(c.moveToFirst()) id = c.getLong(0);
        c.close();
        return id;
    }
}

