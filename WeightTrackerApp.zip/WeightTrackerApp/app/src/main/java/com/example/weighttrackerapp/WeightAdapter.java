package com.example.weighttrackerapp;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;      // needed
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;       // needed
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.VH> {

    // Row model for the list
    public static class Row {
        public long id;
        public String date;
        public double weight;
    }

    // Listener for edit/delete actions
    public interface Listener {
        void onEdit(Row r);
        void onDelete(Row r);
    }

    private final List<Row> rows = new ArrayList<>();
    private final Listener listener;

    public WeightAdapter(Listener l) {
        this.listener = l;
    }

    /** Replace current list from a Cursor: id, date, weight */
    public void submitCursor(Cursor c) {
        rows.clear();
        if (c != null && c.moveToFirst()) {
            do {
                Row r = new Row();
                r.id = c.getLong(0);
                r.date = c.getString(1);
                r.weight = c.getDouble(2);
                rows.add(r);
            } while (c.moveToNext());
            c.close();
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Row r = rows.get(position);
        h.tvDate.setText(r.date);
        h.tvWeight.setText(String.valueOf(r.weight));
        h.btnEdit.setOnClickListener(_v -> listener.onEdit(r));
        h.btnDelete.setOnClickListener(_v -> listener.onDelete(r));
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView tvDate, tvWeight;
        final Button btnEdit, btnDelete;

        VH(@NonNull View v) {
            super(v);
            tvDate = v.findViewById(R.id.tvDate);
            tvWeight = v.findViewById(R.id.tvWeight);
            btnEdit = v.findViewById(R.id.btnEdit);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}

