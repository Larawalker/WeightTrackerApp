package com.example.weighttrackerapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddWeightActivity extends AppCompatActivity {

    private EditText editTextDate, editTextWeight;
    private Button buttonSaveWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonSaveWeight = findViewById(R.id.buttonSaveWeight);

        buttonSaveWeight.setOnClickListener(v -> {
            String date = editTextDate.getText().toString().trim();
            String weight = editTextWeight.getText().toString().trim();

            if (date.isEmpty() || weight.isEmpty()) {
                Toast.makeText(this, "Please enter both date and weight.", Toast.LENGTH_SHORT).show();
            } else {
                // Placeholder: save data later in Project 3
                Toast.makeText(this, "Weight saved! (Not really yet)", Toast.LENGTH_SHORT).show();
                finish(); // go back to previous screen
            }
        });
    }
}
