package com.example.weighttrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.weighttrackerapp.WeightEntry;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        RecyclerView recyclerView = findViewById(R.id.recyclerViewWeights);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<WeightEntry> mockData = new ArrayList<>();
        mockData.add(new WeightEntry("2025-08-01", "145 lbs"));
        mockData.add(new WeightEntry("2025-08-02", "144.2 lbs"));
        mockData.add(new WeightEntry("2025-08-03", "143.8 lbs"));

        WeightAdapter adapter = new WeightAdapter(mockData);
        recyclerView.setAdapter(adapter);

       Button smsButton = findViewById(R.id.buttonSms);
        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, SmsActivity.class);
            startActivity(intent);
        });

        Button addWeightButton = findViewById(R.id.buttonAddWeight);
        addWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, AddWeightActivity.class);
            startActivity(intent);
        });



    }
}


