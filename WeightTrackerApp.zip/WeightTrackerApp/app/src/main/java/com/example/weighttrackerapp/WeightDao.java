package com.example.weighttrackerapp;

public class WeightDao {
    private final AppDbHelper helper;
    public WeightDao(Context ctx){ helper = new AppDbHelper(ctx); }

    public long addWeight(long userId, String isoDate, double weight){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("date", isoDate);
        cv.put("weight", weight);
        return db.insert("weights", null, cv);
    }

    public int updateWeight(long id, double newWeight){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("weight", newWeight);
        return db.update("weights", cv, "id=?", new String[]{String.valueOf(id)});
    }

    public int deleteWeight(long id){
        return helper.getWritableDatabase()
                .delete("weights", "id=?", new String[]{String.valueOf(id)});
    }

    public Cursor allForUser(long userId){
        return helper.getReadableDatabase().rawQuery(
                "SELECT id, date, weight FROM weights WHERE user_id=? ORDER BY date DESC",
                new String[]{ String.valueOf(userId) });
    }

    public void setGoal(long userId, double goal){
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("goal_weight", goal);
        // upsert
        long row = db.insertWithOnConflict("goals", null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        if (row == -1) db.update("goals", cv, "user_id=?", new String[]{String.valueOf(userId)});
    }

    public Double getGoal(long userId){
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT goal_weight FROM goals WHERE user_id=?",
                new String[]{ String.valueOf(userId) });
        Double g = null;
        if(c.moveToFirst()) g = c.getDouble(0);
        c.close(); return g;
    }

    public boolean reachedGoal(long userId, double latestWeight){
        Double g = getGoal(userId);
        return g != null && latestWeight <= g; // reaching goal = <= goal weight
    }
}

